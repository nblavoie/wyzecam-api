var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_0x61.html", null ],
    [ "i", "globals_0x69.html", null ],
    [ "l", "globals_0x6c.html", null ],
    [ "m", "globals_0x6d.html", null ],
    [ "p", "globals_0x70.html", null ],
    [ "r", "globals_0x72.html", null ],
    [ "s", "globals_0x73.html", null ],
    [ "t", "globals_0x74.html", null ]
];