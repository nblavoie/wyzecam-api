var searchData=
[
  ['authfn',['authFn',['../_a_v_a_p_is_8h.html#aa1e5cd6d6ffd8938e788da20ae5c20bc',1,'AVAPIs.h']]],
  ['av_5freset_5ftarget',['AV_RESET_TARGET',['../_a_v_a_p_is_8h.html#aa88e7f838b671ce43dd67254ef08216a',1,'AVAPIs.h']]]
];
