var searchData=
[
  ['reset_5fall',['RESET_ALL',['../_a_v_a_p_is_8h.html#a72023a183ff042503f25a8e15cc01a2da54db1b98fbfcbee9cf5160e9221996bd',1,'AVAPIs.h']]],
  ['reset_5faudio',['RESET_AUDIO',['../_a_v_a_p_is_8h.html#a72023a183ff042503f25a8e15cc01a2dad3e51962574f4e465e6a3b2d10d7e8f5',1,'AVAPIs.h']]],
  ['reset_5fvideo',['RESET_VIDEO',['../_a_v_a_p_is_8h.html#a72023a183ff042503f25a8e15cc01a2daba1a3e06cf7cb509fa45084c2228c81e',1,'AVAPIs.h']]]
];
