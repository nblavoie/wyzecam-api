var searchData=
[
  ['_5fav_5freset_5ftarget',['_AV_RESET_TARGET',['../_a_v_a_p_is_8h.html#a72023a183ff042503f25a8e15cc01a2d',1,'AVAPIs.h']]]
];
