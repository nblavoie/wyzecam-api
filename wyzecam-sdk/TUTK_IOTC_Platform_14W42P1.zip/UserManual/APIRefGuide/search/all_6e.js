var searchData=
[
  ['nattype',['NatType',['../structst___s_info.html#aac5b2467fdbd71a42b02dedb7862e838',1,'st_SInfo']]],
  ['nauthdatalen',['nAuthDataLen',['../structst___p2_p_tunnel_session_info.html#a1c9302b9c0a3852ed814ef75da621fa4',1,'st_P2PTunnelSessionInfo']]],
  ['nmode',['nMode',['../structst___p2_p_tunnel_session_info.html#ae3242b9b0709d103c25524ab9887c5b6',1,'st_P2PTunnelSessionInfo']]],
  ['nnattype',['nNatType',['../structst___p2_p_tunnel_session_info.html#a64315523ef3b110bd9008acc7f596c2e',1,'st_P2PTunnelSessionInfo']]],
  ['nremoteport',['nRemotePort',['../structst___p2_p_tunnel_session_info.html#a998f4da89525c9eaa547de5e2e31fa29',1,'st_P2PTunnelSessionInfo']]],
  ['nsid',['nSID',['../structst___p2_p_tunnel_session_info.html#aa0ffd04e24691668fc0b28715304767d',1,'st_P2PTunnelSessionInfo']]],
  ['nversion',['nVersion',['../structst___p2_p_tunnel_session_info.html#a209de83190f63a1b8a094b0157550800',1,'st_P2PTunnelSessionInfo']]]
];
