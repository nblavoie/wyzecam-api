var searchData=
[
  ['max_5fauth_5fdata_5flen',['MAX_AUTH_DATA_LEN',['../_p2_p_tunnel_a_p_is_8h.html#afbd7022e295342f2f622fa562f0465c0',1,'P2PTunnelAPIs.h']]],
  ['max_5fchannel_5fnumber',['MAX_CHANNEL_NUMBER',['../_i_o_t_c_a_p_is_8h.html#ac9275c1c048464753b84de4e97d1544e',1,'IOTCAPIs.h']]],
  ['max_5fdefault_5fiotc_5fsession_5fnumber',['MAX_DEFAULT_IOTC_SESSION_NUMBER',['../_i_o_t_c_a_p_is_8h.html#a7f87e24de2aae2deda8c63c1ea884a11',1,'IOTCAPIs.h']]],
  ['max_5fdefault_5frdt_5fchannel_5fnumber',['MAX_DEFAULT_RDT_CHANNEL_NUMBER',['../_r_d_t_a_p_is_8h.html#ab79915ea4a919852d340d9a80c6dc237',1,'RDTAPIs.h']]]
];
