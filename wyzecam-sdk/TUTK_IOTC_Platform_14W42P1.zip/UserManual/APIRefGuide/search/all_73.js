var searchData=
[
  ['sessionstatuscb',['sessionStatusCB',['../_i_o_t_c_a_p_is_8h.html#ad12bf90639a802c78bee855dd1054c92',1,'IOTCAPIs.h']]],
  ['sp2ptunnelsessioninfo',['sP2PTunnelSessionInfo',['../_p2_p_tunnel_a_p_is_8h.html#a55f2a7d5fb895a65556a2977d7e97c57',1,'P2PTunnelAPIs.h']]],
  ['st_5flansearchinfo',['st_LanSearchInfo',['../structst___lan_search_info.html',1,'']]],
  ['st_5flansearchinfo2',['st_LanSearchInfo2',['../structst___lan_search_info2.html',1,'']]],
  ['st_5fp2ptunnelsessioninfo',['st_P2PTunnelSessionInfo',['../structst___p2_p_tunnel_session_info.html',1,'']]],
  ['st_5frdt_5fstatus',['st_RDT_Status',['../structst___r_d_t___status.html',1,'']]],
  ['st_5fsinfo',['st_SInfo',['../structst___s_info.html',1,'']]],
  ['szremoteip',['szRemoteIP',['../structst___p2_p_tunnel_session_info.html#af50a5fbe7262a0c1045d72fdf78cb5ce',1,'st_P2PTunnelSessionInfo']]]
];
