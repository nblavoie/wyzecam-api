var searchData=
[
  ['bufsizeinrecvqueue',['BufSizeInRecvQueue',['../structst___r_d_t___status.html#a4b9692692e9feac44bb9d07f632142a8',1,'st_RDT_Status']]],
  ['bufsizeinsendqueue',['BufSizeInSendQueue',['../structst___r_d_t___status.html#a62bead96d2f1f611bf3c06cebe2700bc',1,'st_RDT_Status']]]
];
