var structst___lan_search_info =
[
    [ "IP", "structst___lan_search_info.html#ad98c550a0f2aa2256ad9f2d400e42928", null ],
    [ "port", "structst___lan_search_info.html#ab85ff85aa1f60f4a1c1ca1225a9dad06", null ],
    [ "Reserved", "structst___lan_search_info.html#a9da2be76809eedd60a7543c651fd25ab", null ],
    [ "UID", "structst___lan_search_info.html#ac50e8325e30c566904af247d08936ea4", null ]
];