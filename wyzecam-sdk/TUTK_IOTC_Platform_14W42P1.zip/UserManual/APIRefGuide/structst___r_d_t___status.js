var structst___r_d_t___status =
[
    [ "BufSizeInRecvQueue", "structst___r_d_t___status.html#a4b9692692e9feac44bb9d07f632142a8", null ],
    [ "BufSizeInSendQueue", "structst___r_d_t___status.html#a62bead96d2f1f611bf3c06cebe2700bc", null ],
    [ "Timeout", "structst___r_d_t___status.html#a790f3d2db6cf1f03bbd8232f6072915f", null ],
    [ "TimeoutThreshold", "structst___r_d_t___status.html#a511948fb282305a4fc345ff03bc50c28", null ]
];