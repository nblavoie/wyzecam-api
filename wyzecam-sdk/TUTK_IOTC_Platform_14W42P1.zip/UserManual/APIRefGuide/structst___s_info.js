var structst___s_info =
[
    [ "CorD", "structst___s_info.html#a84fd1d0910c80397d648b30cf8b48f68", null ],
    [ "GID", "structst___s_info.html#a3f76e005fba84d353ee627142a1a4769", null ],
    [ "IOTCVersion", "structst___s_info.html#a54e3002461d56b2074b38ceb61721a46", null ],
    [ "isSecure", "structst___s_info.html#a4661f1a396449f707030f69725251844", null ],
    [ "Mode", "structst___s_info.html#a2bc4b5d8101ed56cddb0aa08aa4516bc", null ],
    [ "NatType", "structst___s_info.html#aac5b2467fdbd71a42b02dedb7862e838", null ],
    [ "PID", "structst___s_info.html#a7c0c2c04f85f5af56595a00b34b8e61b", null ],
    [ "RemoteIP", "structst___s_info.html#a1c84b8d0e8d286931056c3278b0a37b5", null ],
    [ "RemotePort", "structst___s_info.html#abe3861fbe0a0755f020347a4e624d63d", null ],
    [ "RX_Packetcount", "structst___s_info.html#ab4b64dfc5119859f03cf3fa0660dcf99", null ],
    [ "TX_Packetcount", "structst___s_info.html#a52259024414b5a92de2ee9fa388def2a", null ],
    [ "UID", "structst___s_info.html#ac50e8325e30c566904af247d08936ea4", null ],
    [ "VID", "structst___s_info.html#a0b608904ce0347f5259f87c651def5a5", null ]
];