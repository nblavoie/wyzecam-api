/*
 *********************************************************************************
 *     Copyright (c) 2010	ASIX Electronic Corporation      All rights reserved.
 *
 *     This is unpublished proprietary source code of ASIX Electronic Corporation
 *
 *     The copyright notice above does not evidence any actual or intended
 *     publication of such source code.
 *********************************************************************************
 */
 /*============================================================================
 * Module name: CMIME64.c
 * Purpose:
 * Author:
 * Date:
 * Notes:
 * $Log: CMIME64.h,v $
 *
 *=============================================================================
 */

#ifndef __CMIME64_H__
#define __CMIME64_H__

#include "types.h"
void Cmime64_Init(void);
void cmime64(S8_T*);


#endif /* __SMTPC_H__ */

