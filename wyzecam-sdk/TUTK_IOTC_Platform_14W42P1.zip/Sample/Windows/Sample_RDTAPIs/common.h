
#ifndef _COMMON_H_
#define _COMMON_H_

#define START_STRING "Start"
#define RDT_WAIT_TIMEMS 30000
#define MAX_BUF_SIZE 102400

#define MAX_MEM_USE 1024000

#endif
