/** Automatically generated file. DO NOT MODIFY */
package com.example.sample_p2ptunnel;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}