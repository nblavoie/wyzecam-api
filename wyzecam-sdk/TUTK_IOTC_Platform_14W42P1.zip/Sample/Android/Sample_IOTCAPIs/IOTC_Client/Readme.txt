1. Copy library from ../../../../Lib/Android/IOTCAPIs/libs/armeabi/libIOTCAPIs.so to ./libs/armeabi/
   Copy java file from ../../../../Lib/Android/IOTCAPIs/src/com/tutk/IOTC/*.java to ./src/com/tutk/IOTC/
2. Open project "IOTC_Client" and run it on mobile.
